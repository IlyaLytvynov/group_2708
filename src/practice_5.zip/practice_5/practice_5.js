import './practice_5.scss';

const lamp = document.querySelector('.lamp__light');
const button = document.querySelector('.lamp__button');
let intervalId;

function randomValue(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function getRandomColor() {
  return (
    'rgb(' +
    randomValue(0, 255) +
    ',' +
    randomValue(0, 255) +
    ',' +
    randomValue(0, 255) +
    ')'
  );
}

function setColor() {
  lamp.style.background = getRandomColor();
}

function startInterval() {
  intervalId = setInterval(function() {
    setColor();
  }, 1500);
}

function start() {
  setColor();
  startInterval();
}
function stop() {
  clearInterval(intervalId);
  lamp.style.background = '';
}

function toggle() {
  if (lamp.style.background === '') {
    start();
  } else {
    stop();
  }
}

button.onclick = toggle;
